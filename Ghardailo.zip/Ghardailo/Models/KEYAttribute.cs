﻿using System;

namespace Ghardailo.Models
{
    internal class KEYAttribute : Attribute
    {
    }
}